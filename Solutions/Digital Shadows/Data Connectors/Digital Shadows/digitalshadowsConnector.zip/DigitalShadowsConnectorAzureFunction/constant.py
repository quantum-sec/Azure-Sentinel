LOG_NAME = "DigitalShadows"
DAYS = 5
MINUTE = 15                                 #buffer time for current time
FILE_LAST_POLL_TIME = 'last_polled_time'
FILE_LAST_EVENT_NUMBER = 'last_polled_event_number'
FILE_LAST_TRIAGE_ITEMS = 'last_triage_items'