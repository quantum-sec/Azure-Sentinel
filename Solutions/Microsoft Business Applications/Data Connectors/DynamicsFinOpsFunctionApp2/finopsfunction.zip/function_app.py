""" Finance & Operations Data Collector v1.2.0 """
import logging
import os
from datetime import datetime, timedelta
from typing import Union, Generator, List, Dict, Any
import json
import pandas as pd
import httpx
import azure.functions as func
from azure.identity import ManagedIdentityCredential, ClientSecretCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.storage.blob import ContainerClient
from azure.core.exceptions import ResourceNotFoundError, HttpResponseError

LAST_UPDATE_CONTAINER = "lastupdate"
LAST_UPDATE_FILENAME_LOGS = "lastupdatelogs.json"
LAST_UPDATE_FILENAME_DATA = "lastupdatedata.json"
AZURE_WEB_JOBS_STORAGE = os.environ["AzureWebJobsStorage"]
DCR_IMMUTABLE_ID = os.environ["DCR_IMMUTABLE_ID"]
DCR_STREAM_NAME_LOGS = os.environ["DCR_STREAM_NAME_LOGS"]
DCR_STREAM_NAME_USERS = os.environ["DCR_STREAM_NAME_USERS"]
DCR_STREAM_NAME_ROLES = os.environ["DCR_STREAM_NAME_ROLES"]
DCR_STREAM_NAME_USERROLES = os.environ["DCR_STREAM_NAME_USERROLES"]
DCR_DCE_URL = os.environ["DCR_DCE_URL"]
ODATA_API_HOST = os.environ["ODATA_API_HOST"]
ODATA_API_TIMEOUT_SECONDS = int(os.environ["ODATA_API_TIMEOUT_SECONDS"])
ODATA_API_MAX_PAGE_SIZE = int(os.environ["ODATA_API_MAX_PAGE_SIZE"])
FUNCTION_SHUTDOWN_TIMEOUT_MINS = int(os.environ["FUNCTION_SHUTDOWN_TIMEOUT_MINS"])
TIMER_SCHEDULE_LOGS = os.environ["TIMER_SCHEDULE_LOGS"]
TIMER_SCHEDULE_DATA = os.environ["TIMER_SCHEDULE_DATA"]
MAX_LOOKBACK_DURATION_HOURS = int(os.environ["MAX_LOOKBACK_DURATION_HOURS"])
QUERY_WINDOW_OFFSET_MINS = int(os.environ["QUERY_WINDOW_OFFSET_MINS"])
CROSS_COMPANY_QUERY = os.environ["CROSS_COMPANY_QUERY"]
INSTANCE_NAME = os.environ["INSTANCE_NAME"]
LAST_UPDATE_CONTAINER_NAME = "lastupdated"
FILE_CACHE_CONTAINER_NAME = "filecache"
CLIENT_CRED_CLIENT_ID = os.environ.get("CLIENT_CRED_CLIENT_ID", False)
CLIENT_CRED_CLIENT_SECRET = os.environ.get("CLIENT_CRED_CLIENT_SECRET", False)
CLIENT_CRED_TENANT_ID = os.environ.get("CLIENT_CRED_TENANT_ID", False)
FULL_SYNC_INTERVAL_DAYS = int(os.environ["FULL_SYNC_INTERVAL_DAYS"])
DATA_MAPPINGS = [
    (
        "SystemUsers",
        DCR_STREAM_NAME_USERS,
        "cache_systemusers.json",
    ),
    (
        "SecurityRoles",
        DCR_STREAM_NAME_ROLES,
        "cache_securityroles.json",
    ),
    (
        "SecurityUserRoles",
        DCR_STREAM_NAME_USERROLES,
        "cache_systemuserroles.json",
    ),
]

azure_http_logger = logging.getLogger(
    "azure.core.pipeline.policies.http_logging_policy"
)
azure_http_logger.setLevel(logging.WARNING)


def get_data(client: httpx.Client, request_url: str) -> list:
    """GET data from OData API"""
    try:
        response = client.get(
            url=request_url,
        )
        response.raise_for_status()
    except httpx.TimeoutException as exc:
        logging.error("Request timed out: %s", exc)
        raise
    except httpx.HTTPStatusError as exc:
        logging.error("HTTP error: %s, %s", exc.response.status_code, exc.response.text)
        raise
    return response


def get_cached_data(cache_file: str) -> List[Dict[str, Any]]:
    """Read cache file from blob storage"""
    with ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=FILE_CACHE_CONTAINER_NAME
    ) as file_cache_container:
        if not file_cache_container.exists():
            logging.info("No storage container for cache files found")
            return []

        try:
            logging.info("Downloading cache file")
            file_cache_blob = file_cache_container.download_blob(cache_file)
            file_cache_data = json.loads(file_cache_blob.readall())
            return file_cache_data
        except ResourceNotFoundError:
            logging.info("No cache file found in blob storage.")
            return []


def set_cached_data(cache_file: str, data: List[Dict[str, Any]]) -> None:
    """Set the cache file in blob storage"""
    with ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=FILE_CACHE_CONTAINER_NAME
    ) as file_cache_container:
        if not file_cache_container.exists():
            logging.info("No storage container for cache files found")
            file_cache_container.create_container()

        logging.info("Updating cache file %s", cache_file)
        file_cache_container.upload_blob(
            cache_file,
            json.dumps(data),
            overwrite=True,
        )


def get_all_data(client: httpx.Client, request_url: str) -> Generator[list, None, None]:
    """GET data from OData API"""
    next_page_link = True
    while next_page_link:
        logging.info("GET %s", request_url)
        response = get_data(client, request_url)
        response_json = response.json()
        next_page_link = response_json.get("@odata.nextLink", False)
        if next_page_link:
            request_url = next_page_link
        data = response_json.get("value", False)
        if data:
            yield data


def add_instance_name(data: list) -> list:
    """Add instance name to data"""
    for row in data:
        row["InstanceName"] = INSTANCE_NAME
    return data


def send_data(
    dcr_stream: str,
    cred: Union[ManagedIdentityCredential, ClientSecretCredential],
    data: list,
):
    """Send data to Logs Ingestion API"""
    with LogsIngestionClient(endpoint=DCR_DCE_URL, credential=cred) as client:
        try:
            logging.info("Uploading %s logs to Ingestion API", len(data))
            client.upload(rule_id=DCR_IMMUTABLE_ID, stream_name=dcr_stream, logs=data)
        except HttpResponseError as exc:
            logging.error("Logs Ingestion error: %s", exc)
            raise


def get_last_updated_timestamps(last_update_filename: str) -> dict:
    """Get the last updated timestamp from blob storage"""

    empty_timestamp = datetime(1970, 1, 1).isoformat()
    no_updated_timestamps = {
        "last_full_sync": empty_timestamp,
    }

    with ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=LAST_UPDATE_CONTAINER_NAME
    ) as last_update_blob_container:
        if not last_update_blob_container.exists():
            logging.info("No storage container for last update timestamp found")
            return no_updated_timestamps

        try:
            logging.info("Downloading last update timestamp file")
            last_update_blob = last_update_blob_container.download_blob(
                last_update_filename
            )
            last_updated_timestamps = json.loads(last_update_blob.readall())
            return last_updated_timestamps
        except ResourceNotFoundError:
            logging.info("No last update timestamp file found in blob storage.")
            return no_updated_timestamps


def set_last_updated_timestamps(
    last_update_filename: str, last_full_sync: datetime
) -> None:
    """Set the last updated timestamp in blob storage"""
    with ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=LAST_UPDATE_CONTAINER_NAME
    ) as last_update_blob_container:
        if not last_update_blob_container.exists():
            logging.info("No storage container for last update timestamp found")
            last_update_blob_container.create_container()

        logging.info("Updating last update timestamp file")
        last_update_blob_container.upload_blob(
            last_update_filename,
            json.dumps(
                {
                    "last_full_sync": last_full_sync.isoformat(),
                }
            ),
            overwrite=True,
        )


def get_finance_operations_token(
    credential: Union[ManagedIdentityCredential, ClientSecretCredential]
) -> str:
    """Get a token for the Finance & Operations API"""
    return credential.get_token(f"{ODATA_API_HOST}/.default").token


def create_client_headers(token: str) -> dict:
    """Create headers for OData API requests"""
    return {
        "Content-Type": "application/json;odata.metadata=none",
        "Prefer": f"odata.maxpagesize={ODATA_API_MAX_PAGE_SIZE}",
        "authorization": f"Bearer {token}",
    }


is_using_client_credentials = (
    CLIENT_CRED_TENANT_ID and CLIENT_CRED_CLIENT_SECRET and CLIENT_CRED_TENANT_ID
)
function_app_credential = (
    ClientSecretCredential(
        client_id=CLIENT_CRED_CLIENT_ID,
        client_secret=CLIENT_CRED_CLIENT_SECRET,
        tenant_id=CLIENT_CRED_TENANT_ID,
    )
    if is_using_client_credentials
    else ManagedIdentityCredential()
)

app = func.FunctionApp()


@app.timer_trigger(
    schedule=TIMER_SCHEDULE_LOGS,
    arg_name="FinanceOperationsLogs",
    run_on_startup=False,
    use_monitor=True,
)
# pylint: disable=invalid-name
def finance_operations_logs(FinanceOperationsLogs: func.TimerRequest) -> None:
    """Main function for the Azure Function App"""

    function_start_time_utc = datetime.utcnow().replace(microsecond=0)
    max_lookback_duration = function_start_time_utc - timedelta(
        hours=MAX_LOOKBACK_DURATION_HOURS
    )
    query_window_end = (
        function_start_time_utc - timedelta(minutes=QUERY_WINDOW_OFFSET_MINS)
    ).isoformat()

    if FinanceOperationsLogs.past_due:
        logging.info("The timer is past due!")

    last_update_blob = get_last_updated_timestamps(
        last_update_filename=LAST_UPDATE_FILENAME_LOGS
    )
    query_window_start = last_update_blob["last_full_sync"]

    if datetime.fromisoformat(query_window_start) < max_lookback_duration:
        logging.warning(
            "Last update date exceeds limit of %s hours. Older events will not be collected",
            MAX_LOOKBACK_DURATION_HOURS,
        )
        query_window_start = max_lookback_duration.isoformat()

    token = get_finance_operations_token(credential=function_app_credential)
    client_headers = create_client_headers(token)

    last_data_timestamp = False
    with httpx.Client(
        base_url=ODATA_API_HOST,
        timeout=ODATA_API_TIMEOUT_SECONDS,
        headers=client_headers,
    ) as client:
        api_path = "/data/DatabaseLogs"
        query_string = "".join(
            [
                f"?$filter=LogCreatedDateTime gt {query_window_start}Z ",
                f"and LogCreatedDateTime le {query_window_end}Z",
            ]
        )
        cross_company_parameter = f"&cross-company={CROSS_COMPANY_QUERY}"
        request_url = f"{api_path}{query_string}{cross_company_parameter}"

        for data in get_all_data(client=client, request_url=request_url):
            add_instance_name(data)
            send_data(
                dcr_stream=DCR_STREAM_NAME_LOGS,
                cred=function_app_credential,
                data=data,
            )
            last_data_timestamp = datetime.fromisoformat(
                data[-1]["LogCreatedDateTime"].replace("Z", "")
            ).isoformat()

    if last_data_timestamp:
        logging.info(
            "Uploading last update timestamp JSON to blob storage %s",
            last_data_timestamp,
        )
        set_last_updated_timestamps(
            last_update_filename=LAST_UPDATE_FILENAME_LOGS,
            last_full_sync=datetime.fromisoformat(last_data_timestamp),
        )


@app.timer_trigger(
    schedule=TIMER_SCHEDULE_DATA,
    arg_name="FinanceOperationsData",
    run_on_startup=False,
    use_monitor=True,
)
# pylint: disable=invalid-name
def finance_operations_data(FinanceOperationsData: func.TimerRequest) -> None:
    """Main function for the Azure Function App"""
    if FinanceOperationsData.past_due:
        logging.info("The timer is past due!")

    function_start_time = datetime.utcnow()
    last_update = get_last_updated_timestamps(
        last_update_filename=LAST_UPDATE_FILENAME_DATA
    )
    last_full_sync = datetime.fromisoformat(last_update["last_full_sync"])
    full_sync = last_full_sync < function_start_time - timedelta(
        days=FULL_SYNC_INTERVAL_DAYS
    )

    token = get_finance_operations_token(credential=function_app_credential)
    client_headers = create_client_headers(token)

    for odata_entity, dcr_stream, cache_file in DATA_MAPPINGS:
        current_data = []
        with httpx.Client(
            base_url=ODATA_API_HOST,
            timeout=ODATA_API_TIMEOUT_SECONDS,
            headers=client_headers,
            params={"$cross-company": CROSS_COMPANY_QUERY},
        ) as client:
            request_url = f"/data/{odata_entity}"
            for data in get_all_data(client=client, request_url=request_url):
                add_instance_name(data)
                current_data.extend(data)

        data = (
            current_data
            if full_sync
            else (
                pd.merge(
                    pd.DataFrame(get_cached_data(cache_file=cache_file)),
                    pd.DataFrame(current_data),
                    how="right",
                    indicator=True,
                )
                .query('_merge == "right_only"')
                .drop(columns=["_merge"])
                .to_dict(orient="records")
            )
        )
        send_data(
            dcr_stream=dcr_stream,
            cred=function_app_credential,
            data=data,
        )
        set_cached_data(cache_file=cache_file, data=current_data)

    if full_sync:
        set_last_updated_timestamps(
            last_update_filename=LAST_UPDATE_FILENAME_DATA,
            last_full_sync=function_start_time,
        )
